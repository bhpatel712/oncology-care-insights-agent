"""
Oncology Care Insights Agent — Streamlit chat frontend.
"""

# TODO Week 4: Implement Streamlit chat UI

# import streamlit as st

# Features to build:
# - Chat input + message history
# - Citation display (which guideline passage was retrieved)
# - Tool call trace (which tool(s) fired per answer)
# - "Synthetic data / decision support only" banner
# - Loading spinner during agent calls
# - Error handling for tool failures

if __name__ == "__main__":
    print("Frontend not yet implemented — coming in Week 4")
