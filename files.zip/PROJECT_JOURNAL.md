# Oncology Care Insights Agent — Project Journal

**Project:** Oncology Care Insights Agent
**Developer:** Bhargavi Patel
**Started:** June 28, 2026
**Last Updated:** July 16, 2026
**Platform:** Microsoft Foundry on Azure
**Exam Target:** AI-103 — Early September 2026

---

## Project Definition

**Name:** Oncology Care Insights Agent

**Definition:**
A clinical operations decision-support agent that answers oncology questions by combining NCI cancer treatment guidelines with synthetic patient population data — built on Microsoft Foundry using Azure AI Search, Azure SQL, and GPT-5-mini.

**Resume One-liner:**
> "Built an agent-based AI application on Microsoft Foundry that helps clinical-ops analysts query NCI oncology guidelines and synthetic patient cohorts in plain language — deployed on Azure with RAG, tool-calling, and responsible AI guardrails."

**Cancer Types in Scope:** Breast · Lung · Colorectal

**Responsible AI Framing:**
- Decision-support only — not a clinical diagnostic tool
- All patient data is fully synthetic (Synthea/mCODE — zero real PHI)
- Agent will not diagnose or treat real patients
- Every answer cites its source

---

## Architecture Overview

```
User (Care-ops Analyst)
        ↓
Chat Web App (Streamlit / React)
        ↓
Microsoft Foundry Agent Service (GPT-5-mini + tool calling)
        ↓                    ↓
Azure AI Search          Azure SQL Database
(NCI PDQ Guidelines)     (Synthea/mCODE Patients)
Vector + Semantic         Parameterized SQL queries
Hybrid Retrieval          get_cohort_stats()
                          get_treatment_distribution()
```

**How it works:**
1. Analyst asks a plain-language question in the chat UI
2. Frontend sends message to backend API
3. Backend calls Foundry Agent Service via `azure-ai-projects` SDK
4. Agent reasons and decides which tool(s) to call:
   - `search_guidelines` → Azure AI Search (NCI PDQ retrieval)
   - `query_patient_cohort` → Azure Function → SQL on Azure SQL
5. Agent assembles a grounded, cited answer
6. Frontend displays answer with citations and tool call trace

---

## Azure Resources

| Service | Resource Name | Region | Tier | Status |
|---|---|---|---|---|
| Microsoft Foundry | oncology-care-insights | East US | Pay-as-you-go | ✅ Live |
| Chat model | gpt-5-mini | East US | Standard | ✅ Deployed |
| Embedding model | text-embedding-3-small | East US | Standard | ✅ Deployed |
| Application Insights | oncology-care-insights-resource-appinsights | East US | Pay-as-you-go | ✅ Auto-created |
| Log Analytics | oncology-care-insights-resource-logs | East US | Pay-as-you-go | ✅ Auto-created |
| Azure AI Search | oncology-search | East US | Free | ✅ Live |
| Azure SQL Database | oncology-patients | Central US | Basic | ✅ Live |
| Azure Key Vault | oncology-kv-2026 | Central US | Standard | ✅ Live |
| Managed Identity | System Assigned | N/A | N/A | ✅ Enabled |
| Budget Alert | oncology-project-budget | N/A | $30 limit | ✅ Active |

**RBAC Configured:**
- SQL DB Contributor → oncology-care-insights-resource
- Search Index Data Contributor → oncology-care-insights-resource
- Key Vault Secrets User → oncology-care-insights-resource

---

## Data Assets

### Patient Data (Synthetic — Zero PHI)

| Dataset | Files | Format | Focus |
|---|---|---|---|
| Mixed cancer types | 2,100 files | FHIR R4 JSON (mCODE) | Lung, colorectal + others |
| Breast cancer focused | 1,113 files | FHIR R4 JSON (mCODE) | Breast cancer |
| **Total** | **3,213 files** | FHIR R4 JSON | All 3 cancer types |

**Source:** MITRE Corporation mCODE synthetic dataset (July 2022), conformant with mCODE STU2. Free of cost, privacy, and security restrictions.

**Cancer types confirmed in data (sample of 100 files):**
- Malignant neoplasm of breast: 45 patients
- Suspected lung cancer: 12 patients
- Colorectal cancer (all variants): 30 patients
- Total in-scope: 87 out of 100 sampled

**FHIR Resource Structure per patient (example: Katherine209 Reichert620):**
- Total resources: 289
- Observation: 126 (lab results, tumor markers, vitals)
- Procedure: 52 (surgeries, chemo, radiation)
- DiagnosticReport: 26 (pathology reports)
- DocumentReference: 24 (clinical notes)
- Encounter: 24 (hospital visits)
- MedicationRequest: 7 (treatment regimens)
- Condition: 5 (cancer diagnosis + comorbidities)
- Patient: 1 (demographics)

### Guideline Knowledge (Planned — Week 2)

| Cancer Type | Source | Status |
|---|---|---|
| Breast cancer | NCI PDQ health-professional summaries | 🔜 Download Week 2 |
| Lung cancer | NCI PDQ health-professional summaries | 🔜 Download Week 2 |
| Colorectal cancer | NCI PDQ health-professional summaries | 🔜 Download Week 2 |

---

## Azure SQL Schema (Designed — Week 2)

```sql
-- 1. Patients
CREATE TABLE Patients (
    patient_id NVARCHAR(100) PRIMARY KEY,
    first_name NVARCHAR(100),
    last_name NVARCHAR(100),
    gender NVARCHAR(20),
    birth_date DATE,
    race NVARCHAR(100),
    ethnicity NVARCHAR(100),
    state NVARCHAR(50),
    dataset_source NVARCHAR(50)
);

-- 2. Conditions (cancer diagnoses)
CREATE TABLE Conditions (
    condition_id NVARCHAR(100) PRIMARY KEY,
    patient_id NVARCHAR(100),
    condition_code NVARCHAR(50),
    condition_text NVARCHAR(500),
    onset_date DATE,
    abatement_date DATE,
    is_cancer BIT,
    cancer_type NVARCHAR(100),
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id)
);

-- 3. Treatments (medications + procedures)
CREATE TABLE Treatments (
    treatment_id NVARCHAR(100) PRIMARY KEY,
    patient_id NVARCHAR(100),
    treatment_type NVARCHAR(50),
    treatment_code NVARCHAR(50),
    treatment_text NVARCHAR(500),
    start_date DATE,
    end_date DATE,
    status NVARCHAR(50),
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id)
);

-- 4. Observations (lab results, tumor markers)
CREATE TABLE Observations (
    observation_id NVARCHAR(100) PRIMARY KEY,
    patient_id NVARCHAR(100),
    observation_code NVARCHAR(50),
    observation_text NVARCHAR(500),
    observation_value NVARCHAR(200),
    observation_unit NVARCHAR(50),
    observation_date DATE,
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id)
);

-- 5. Encounters (hospital visits)
CREATE TABLE Encounters (
    encounter_id NVARCHAR(100) PRIMARY KEY,
    patient_id NVARCHAR(100),
    encounter_type NVARCHAR(100),
    encounter_date DATE,
    end_date DATE,
    reason_text NVARCHAR(500),
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id)
);
```

---

## Development Environment

| Tool | Version | Status |
|---|---|---|
| VS Code | Latest | ✅ Installed |
| Python | 3.14.6 | ✅ Installed |
| Virtual environment | .venv (Python 3.14.6) | ✅ Active |
| azure-ai-projects | 2.0.0+ | ✅ Installed |
| azure-search-documents | 11.6.0 | ✅ Installed |
| azure-identity | 1.17.0 | ✅ Installed |
| openai | 1.40.0+ | ✅ Installed |
| pandas | 3.0.3 | ✅ Installed |
| pyodbc | 5.3.0 | ✅ Installed (needs unixODBC) |
| SQLAlchemy | 2.0.51 | ✅ Installed |
| pymssql | TBD | 🔜 Install tomorrow |
| streamlit | 1.59.2 | ✅ Installed |
| tiktoken | 0.13.0 | ✅ Installed |

**VS Code Extensions:**
- Python (Microsoft) ✅
- Jupyter (Microsoft) ✅
- Azure Resources (Microsoft) ✅
- SQL Server mssql (Microsoft) ✅
- Foundry Toolkit (Microsoft) ✅

---

## Project Folder Structure

```
oncology-care-insights-agent/
├── README.md                         ✅ Written
├── requirements.txt                  ✅ All packages installed
├── .env                              ✅ All keys configured
├── .env.example                      ✅ Template ready
├── .gitignore                        ✅ Secrets protected
├── .venv/                            ✅ Python 3.14.6
├── data/
│   ├── raw/
│   │   ├── mixed-cancer/             ✅ 2,100 mCODE FHIR files
│   │   └── breast-cancer/            ✅ 1,113 mCODE FHIR files
│   ├── processed/                    🔜 ETL output (Week 2)
│   └── eval/eval_questions.md        ✅ Template ready
├── docs/
│   ├── scope.md                      ✅ Written
│   ├── architecture.md               ✅ Template ready
│   ├── setup.md                      ✅ Template ready
│   ├── checklist.md                  ✅ Full 8-week plan
│   └── eval_results.md               ✅ Template ready
├── infra/
│   ├── main.bicep                    ✅ Skeleton (Week 6)
│   └── parameters.json               ✅ Ready
├── notebooks/
│   ├── 01_data_exploration.ipynb     ✅ RUNNING — cancer types confirmed
│   └── 02_retrieval_validation.ipynb ✅ Skeleton (Week 2)
├── src/
│   ├── agent/
│   │   ├── agent_definition.py       ✅ Skeleton (Week 3)
│   │   └── system_prompt.txt         ✅ Written — guardrails included
│   ├── tools/
│   │   ├── sql_tool.py               ✅ Skeleton (Week 3)
│   │   └── search_tool.py            ✅ Skeleton (Week 3)
│   ├── indexer/
│   │   ├── chunker.py                ✅ Skeleton (Week 2)
│   │   ├── embedder.py               ✅ Skeleton (Week 2)
│   │   └── run_indexer.py            ✅ Skeleton (Week 2)
│   └── api/main.py                   ✅ Skeleton (Week 4)
├── frontend/app.py                   ✅ Skeleton (Week 4)
├── tests/test_tools.py               ✅ Skeleton (Week 3-4)
└── .github/workflows/deploy.yml      ✅ Skeleton (Week 6)
```

---

## Key Decisions Made

| Decision | Reason |
|---|---|
| gpt-5-mini instead of GPT-4o | GPT-4o deprecated for new accounts; gpt-5-mini is GA and sufficient |
| text-embedding-3-small instead of large | Large model unavailable on free quota; small gives excellent RAG quality |
| Azure SQL instead of Cosmos DB | Leverages 11+ years SQL experience; Synthea CSV maps to relational tables |
| Central US for SQL | East US quota unavailable on free account |
| oncology-kv-2026 Key Vault name | Original name soft-deleted and reserved |
| mCODE FHIR dataset | More realistic than CSV — real-world oncology interoperability standard |
| pymssql instead of pyodbc | pyodbc requires unixODBC system driver not available on Mac without Homebrew |

---

## Week-by-Week Progress

### Week 1 (Jul 8–14) — Plan & Provision ✅ COMPLETE

- [x] Created Azure free account
- [x] Created resource group: `oncology-agent-rg`
- [x] Created Foundry project: `oncology-care-insights`
- [x] Deployed gpt-5-mini (chat model)
- [x] Deployed text-embedding-3-small (embedding model)
- [x] Provisioned Azure AI Search: `oncology-search` (Free tier)
- [x] Provisioned Azure SQL Database: `oncology-patients` (Basic tier)
- [x] Created Azure Key Vault: `oncology-kv-2026`
- [x] Added `sql-admin-password` secret to Key Vault
- [x] Configured `.env` file with all endpoints + API keys
- [x] Set up VS Code + Python 3.14.6 + virtual environment
- [x] Installed all Python packages from requirements.txt
- [x] Installed all VS Code extensions

### Week 2 (Jul 15–16) — Data Pipeline ⏳ IN PROGRESS (40%)

- [x] Configured Managed Identity (system assigned — auto-enabled by Azure)
- [x] RBAC: SQL DB Contributor → Foundry resource
- [x] RBAC: Search Index Data Contributor → Foundry resource
- [x] RBAC: Key Vault Secrets User → Foundry resource
- [x] Azure SQL firewall: Added Mac IP + Allow Azure services
- [x] Budget alert: $30 / 80% threshold
- [x] Downloaded mCODE mixed cancer dataset (2,100 files)
- [x] Downloaded mCODE breast cancer dataset (1,113 files)
- [x] Confirmed all 3 cancer types in data (notebook exploration)
- [x] Designed Azure SQL schema (5 tables)
- [ ] Install pymssql + connect to Azure SQL
- [ ] Create 5 tables in Azure SQL
- [ ] Write Python ETL to parse FHIR JSON → SQL tables
- [ ] Load all 3,213 patient files into Azure SQL
- [ ] Validate with cohort-count SQL queries
- [ ] Pull NCI PDQ summaries for breast + lung + colorectal cancer
- [ ] Clean + tag metadata (cancer_type, stage, section, source_url)
- [ ] Write chunking script (500–800 token chunks with overlap)
- [ ] Generate embeddings
- [ ] Push to Azure AI Search (vector + semantic hybrid)
- [ ] Test retrieval against 15 sample questions per cancer type

### Week 3 (Jul 22–28) — Agent & Tools 🔜 NOT STARTED

- [ ] Set up Foundry Agent Service
- [ ] Write agent system prompt
- [ ] Wire Azure AI Search as retrieval tool
- [ ] Build Azure Function wrapping SQL queries
- [ ] Register SQL function as agent tool
- [ ] Test multi-tool questions
- [ ] Stress-test guardrails

### Week 4 (Jul 29–Aug 4) — Front-end & Safety 🔜 NOT STARTED

- [ ] Build Streamlit chat frontend
- [ ] Wire to agent via azure-ai-projects SDK
- [ ] Add citation display
- [ ] Turn on Content Safety filters
- [ ] Wire Application Insights tracing

### Week 5 (Aug 5–11) — Evaluation 🔜 NOT STARTED

- [ ] Build 50-question eval set
- [ ] Run Foundry evaluation SDK
- [ ] Iterate and re-run evals
- [ ] Document before/after improvement

### Week 6 (Aug 12–18) — Deploy & Polish 🔜 NOT STARTED

- [ ] Write Bicep templates
- [ ] Set up GitHub Actions CI/CD
- [ ] Write README + architecture diagram
- [ ] Record demo video
- [ ] Write case-study post

### Week 7 (Aug 19–25) — AI-103 Gap: Computer Vision 🔜 NOT STARTED

### Week 8 (Aug 26–Sep 1) — AI-103 Gap: Text Analysis + Final Prep 🔜 NOT STARTED

---

## AI-103 Study Progress

| Domain | Weight | Status | Covered by |
|---|---|---|---|
| Domain 1 — Plan & manage Azure AI solutions | 25–30% | 🟡 In progress | Week 1–2 provisioning |
| Domain 2 — Generative AI & agentic solutions | 30–35% | 🔜 Weeks 2–5 | RAG, agent, tools, evals |
| Domain 3 — Computer vision | 10–15% | 🔜 Week 7 | Dedicated gap week |
| Domain 4 — Text analysis | 10–15% | 🔜 Week 8 | Dedicated gap week |
| Domain 5 — Information extraction | 10–15% | 🔜 Weeks 2–3 | NCI PDQ chunking |

**Domain 1 Concepts Learned:**
- Foundry Hub vs Project structure
- Managed Identity vs API key authentication
- Pay-as-you-go vs PTU pricing
- Azure AI Search tiers (Free/Basic/Standard)
- Microsoft's 6 Responsible AI principles
- RBAC roles for AI services
- Azure Cost Management + budget alerts

**Study Plan:**
- Tonight: RAG fundamentals — learn.microsoft.com
- Jul 17: Vector search overview
- Jul 18: Chunking strategies
- Weekend: Practice questions — open-exam-prep.com/practice/ai-103
- Exam: Early September 2026

---

## Tomorrow's Plan (Jul 17)

1. Install pymssql: `pip install sqlalchemy pymssql`
2. Add `AZURE_SQL_PASSWORD` to `.env` file
3. Connect to Azure SQL from notebook
4. Create 5 tables using the schema above
5. Write Python ETL to parse FHIR JSON files
6. Load first 100 patients into Azure SQL
7. Validate with cohort-count queries

---

## Known Limitations (Document in README)

- Synthea breast cancer module lacks full pathologic staging and genomics
- Cohort queries reflect synthetic population patterns, not real clinical data
- Designed for analyst/ops audience — not for point-of-care or patient-facing use
- gpt-5-mini used instead of GPT-4o due to free account quota limits

---

*Last updated: July 16, 2026*
*Next update: July 17, 2026 after ETL session*
