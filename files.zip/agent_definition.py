"""
Oncology Care Insights Agent — Agent definition and tool registration.
Uses azure-ai-projects SDK 2.0.0+ with Foundry Agent Service.
"""

# TODO Week 3: Implement agent setup
# from azure.ai.projects import AIProjectClient
# from azure.identity import DefaultAzureCredential

AGENT_NAME = "oncology-care-insights-agent"
AGENT_MODEL = "gpt-4o"

# Load system prompt from file
import os
_dir = os.path.dirname(__file__)
with open(os.path.join(_dir, "system_prompt.txt"), "r") as f:
    SYSTEM_PROMPT = f.read()
