"""
SQL tool — Azure Function wrapper for parameterized patient cohort queries.
Registered as a tool on the Foundry Agent Service.
"""

# TODO Week 3: Implement SQL tool functions

def get_cohort_stats(cancer_type: str, stage: str = None) -> dict:
    """
    Returns count and basic stats for patients matching cancer_type and optional stage.
    cancer_type: 'breast' | 'lung' | 'colorectal'
    stage: 'I' | 'II' | 'III' | 'IV' | None (all stages)
    """
    pass

def get_treatment_distribution(cancer_type: str) -> dict:
    """
    Returns breakdown of treatment regimens in use for a given cancer type.
    """
    pass

def get_patient_panel_summary(cancer_type: str) -> dict:
    """
    Returns age distribution, gender split, and encounter frequency for a cancer type.
    """
    pass
